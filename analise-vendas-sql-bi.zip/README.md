# Análise de Vendas com SQL e Power BI

## Objetivo
Projeto de análise de vendas de uma empresa fictícia utilizando SQL para modelagem,
consultas e geração de métricas de negócio.

## Tecnologias
- SQL (SQLite)
- Excel
- Power BI

## Análises
- Faturamento total
- Ticket médio
- Produtos mais vendidos
- Faturamento por estado
- Evolução mensal

## Resultado
Dashboard interativo para apoio à tomada de decisão.