INSERT INTO clientes VALUES
(1, 'Ana Souza', 'Rio de Janeiro', 'RJ'),
(2, 'Carlos Lima', 'Niterói', 'RJ'),
(3, 'Mariana Alves', 'São Paulo', 'SP'),
(4, 'João Pereira', 'Campinas', 'SP'),
(5, 'Lucas Rocha', 'Belo Horizonte', 'MG');

INSERT INTO produtos VALUES
(1, 'Notebook Dell', 'Informática', 4500.00),
(2, 'Mouse Logitech', 'Periféricos', 150.00),
(3, 'Teclado Mecânico', 'Periféricos', 350.00),
(4, 'Monitor LG 24"', 'Informática', 1200.00),
(5, 'Headset Gamer', 'Acessórios', 400.00);

INSERT INTO vendas VALUES
(1, 1, 1, '2024-01-10', 1, 4500.00),
(2, 2, 2, '2024-01-12', 2, 300.00),
(3, 3, 3, '2024-02-05', 1, 350.00),
(4, 4, 4, '2024-02-20', 1, 1200.00),
(5, 5, 5, '2024-03-15', 1, 400.00),
(6, 1, 2, '2024-03-18', 1, 150.00),
(7, 2, 3, '2024-04-02', 2, 700.00),
(8, 3, 1, '2024-04-10', 1, 4500.00);